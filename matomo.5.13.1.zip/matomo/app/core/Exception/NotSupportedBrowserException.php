<?php

/**
 * Matomo - free/libre analytics platform
 *
 * @link    https://matomo.org
 * @license https://www.gnu.org/licenses/gpl-3.0.html GPL v3 or later
 */
namespace Piwik\Exception;

use Piwik\Http\HttpCodeException;
class NotSupportedBrowserException extends \Piwik\Exception\Exception implements HttpCodeException
{
    public function __construct($message)
    {
        // Use HTTP code 400 to avoid server-provided 403 error page.
        parent::__construct($message, $code = 400);
    }
}
