<?php

/**
 * Matomo - free/libre analytics platform
 *
 * @link    https://matomo.org
 * @license https://www.gnu.org/licenses/gpl-3.0.html GPL v3 or later
 */
namespace Piwik\Plugin\ConsoleCommand;

use Matomo\Dependencies\Symfony\Component\Console\Output\ConsoleOutput;
/**
 * Wrapper for Symphony console output class
 */
class ConsoleCommandConsoleOutput extends ConsoleOutput
{
}
