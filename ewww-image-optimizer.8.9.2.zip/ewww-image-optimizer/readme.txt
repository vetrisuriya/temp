=== EWWW Image Optimizer ===
Contributors: nosilver4u
Donate link: https://ewww.io/donate/
Tags: compress, convert, webp, resize, lazy load
Tested up to: 7.1
Stable tag: 8.9.2
License: GPLv3

Comprehensive image optimization with WebP, AVIF, Lazy Load, and more. Optimize images automatically for Faster Sites and Happy Visitors.

== Description ==

Are you frustrated by a slow website? Do over-sized images make you say “ewww”... Image optimization with EWWW Image Optimizer helps you make your site faster, improve your bounce rate, and boost your SEO. But most importantly, make your visitors happier so they keep coming back for more.

= Why use EWWW Image Optimizer? =

**Get all this for free:**

* Unlimited image optimization to compress images of any size
* Local image optimization mode compatible with [most web hosts](https://docs.ewww.io/article/43-supported-web-hosts)
* Lossless JPG, PNG, GIF, and SVG image optimization (8% average savings)
* WebP conversion compatible with all web hosts (60% average savings)
* Optimize images from [any plugin](https://docs.ewww.io/article/84-plugin-compatibility)
* Image Detective to help you identify improperly scaled images and better optimize LCP images
* Resize images at upload or in bulk
* Lazy Load with auto-scaling for responsive images–uses properly-sized placeholders to prevent layout shift (CLS)
* Sharpen thumbnail images for better quality
* Adjust JPG and WebP quality (AVIF quality configurable in premium)
* Control creation and optimization of individual WordPress thumbnails
* Convert images to the best format (GIF to PNG, PNG to JPG or vice versa)
* Local image backups
* Preserve GIF animations in thumbnails
* [Free email support](https://ewww.io/contact-us/)

EWWW Image Optimizer is the only plugin that lets you optimize images using tools on your own web server (jpegtran, optipng, pngout, pngquant, gifsicle, cwebp). This requires the PHP exec() function and a [compatible](https://docs.ewww.io/article/43-supported-web-hosts) Linux, Windows, MacOS, or FreeBSD web server. [If your web server is not compatible, we offer unlimited lossless JPG image optimization and WebP conversion via our Compress API **for free**](https://docs.ewww.io/article/29-what-is-exec-and-why-do-i-need-it).

**Upgrade to [Premium](https://ewww.io/plans/) for:**

* 5x premium image optimization
* PDF optimization
* Automatic scaling for all images, even those in external CSS
* One-click WebP & AVIF conversion and delivery
* Enhanced responsive images that use correct dimensions for all devices
* WebP image optimization
* Deliver High-DPI images to devices with 2x and 3x screens (retina)
* Watermark images
* CDN delivery for images, CSS, JS, and fonts with custom domain name option
* 30-day cloud-based backups
* [Premium support](https://ewww.io/about/)

[Premium plans](https://ewww.io/plans/) include SWIS Performance plugin with:

* Page caching
* Enable browser caching with long cache lifetimes
* Defer JS/CSS to eliminate render blocking requests
* Minify JS/CSS
* Critical CSS generation to prevent layout shifting (CLS)
* Optimize font display/self-host Google fonts
* Preload assets like fonts and LCP images
* Reduce unused JS/CSS
* Manage speculative loading


= Automatic Everything =

Optimize images on your entire site with a single click. With [Easy IO CDN](https://ewww.io/plans/), images are automatically compressed, scaled to fit the page and device size, lazy loaded, and converted to next-gen WebP and AVIF formats.

= Support =

[We provide free one-on-one email support to everyone](https://ewww.io/contact-us/).
Do you have an idea to make EWWW Image Optimizer even better? [Share it and vote on future features](https://feedback.ewww.io/b/features)!

Found a bug? Report the issue on [GitHub](https://github.com/nosilver4u/ewww-image-optimizer), and we'll get it fixed!

You may report security issues through our Patchstack Vulnerability Disclosure Program. The Patchstack team helps validate, triage and handle any security vulnerabilities. [Report a security vulnerability.](https://patchstack.com/database/vdp/ewww-image-optimizer)

= Bulk Optimize =

Optimize images, all from a single page. This includes the Media Library, your theme, and a handful of pre-configured folders (see Optimize Everything Else below). GRAND FlaGallery, NextCellent and NextGEN have their own Bulk Optimize pages.

= Optimize Everything Else =

Configure any folder within your WordPress install to optimize images. The Bulk Optimizer will compress theme images, BuddyPress avatars, BuddyPress Activity Plus images, Meta Slider slides, WP Symposium Pro avatars, GD bbPress attachments, Grand Media Galleries, and any user-specified folders. You can also use Scheduled optimization or run the optimizer from WP-CLI if that's more your thing.

= Plugin Compatibility =

EWWW Image Optimizer has been tested with thousands of [plugins and themes](https://docs.ewww.io/article/84-plugin-compatibility), here are just a few of the most common ones: BuddyPress (Activity Plus add-on too), Cloudinary, Easy Watermark, FileBird, FooGallery, GD bbPress Attachments, GRAND FlAGallery, Gmedia Photo Gallery, MediaPress, Meta Slider, Microsoft Azure Storage, MyArcadePlugin, NextGEN Gallery, Regenerate Thumbnails, [Weglot](https://weglot.com/integrations/wordpress-translation-plugin/demo/), WP Offload Media, [WPML](https://wpml.org/plugin/ewww-image-optimizer/), WP Retina 2x, WP RSS Aggregator, WP Symposium, [and more...](https://docs.ewww.io/article/84-plugin-compatibility)

= WebP Images =

If you want simple, get automatic WebP conversion with Easy IO, and be done with it! Otherwise, you can generate WebP versions of unlimited images with the Bulk Optimizer. Deliver them to supported browsers with Apache-style rewrite rules, JS WebP Rewriting, or Picture WebP Rewriting. EWWW Image Optimizer even works with the WebP option in the Cache Enabler plugin from KeyCDN.

= AVIF Images = 

AVIF conversion is built into the Easy IO CDN. Once your site is setup with Easy IO, edit the site settings to enable AVIF, and you're done!

= WP-CLI =

Allows you to run all batch image processes from the command line, instead of the web interface. Optimize images even faster, run it in 'screen' or via regular cron (instead of wp-cron, which can be unpredictable on low-traffic sites). Install WP-CLI from wp-cli.org, and run 'wp-cli.phar help ewwwio optimize' for more information or see the [Docs](https://docs.ewww.io/article/25-optimizing-with-wp-cli).

= CDN Support =

[WP Offload Media](https://wordpress.org/plugins/amazon-s3-and-cloudfront/) is the officially supported (and recommended) plugin for uploads to Amazon S3, Digital Ocean Spaces, and Google Cloud Storage. [Check our compatibility list for details on other plugins](https://docs.ewww.io/article/84-plugin-compatibility). All pull mode CDNs like Cloudflare, KeyCDN, Bunny CDN and Sucuri work automatically, but you will need to purge the CDN cache after you optimize images with bulk optimization.

= Client-Side Media Processing =

EWWW IO is fully compatible with browser-based thumbnail generation, but if you encounter any issues, you may [disable the in-browser image handling in Ludicrous Mode](https://docs.ewww.io/article/11-advanced-configuration). 

= Translations =

Huge thanks to all our translators, [see the full list](https://translate.wordpress.org/projects/wp-plugins/ewww-image-optimizer/contributors)!

If you would like to help translate this plugin, [join the team](https://translate.wordpress.org/projects/wp-plugins/ewww-image-optimizer).
[Signup to receive updates when new strings are available for translation](https://ewww.io/register/).

== Installation ==

1. The plugin will attempt to install jpegtran, optipng, and gifsicle automatically for you. This requires that the wp-content folder is writable by the user running the web server.
1. If the binaries don't run locally, you may sign up for cloud-based optimization: https://ewww.io/plans/
1. Visit the settings page to customize the plugin for your site.
1. *Recommended* Activate the [Easy IO CDN](https://ewww.io/plans/) and/or run the bulk process to compress your existing images.
1. Done!

If these steps do not work, [see the additional documentation](https://docs.ewww.io/article/6-the-plugin-says-i-m-missing-something). If you need further assistance using the plugin, please visit our [Support Page](https://ewww.io/contact-us/).

= Webhosts =

To find out if your webhost works with the EWWW Image Optimizer, you can check the [official list](https://docs.ewww.io/article/43-supported-web-hosts).

== Frequently Asked Questions ==

= Does the plugin remove EXIF and/or IPTC metadata?

EWWW Image Optimizer will remove metadata by default, but if you need to keep the EXIF/IPTC data for copyright purposes, you can disable the Remove Metadata option.
EXIF data does not impact SEO, and it is recommended by Google (and just about everyone else) to remove EXIF data.

= Google Pagespeed says my images need compressing or resizing, but I already optimized all my images. What do I do? =

Try this for starters: [https://docs.ewww.io/article/5-pagespeed-says-my-images-need-more-work](https://docs.ewww.io/article/5-pagespeed-says-my-images-need-more-work)

= The plugin complains that I'm missing something, what do I do? =

This article will walk you through installing the required tools (and the alternatives if installation does not work): [https://docs.ewww.io/article/6-the-plugin-says-i-m-missing-something](https://docs.ewww.io/article/6-the-plugin-says-i-m-missing-something)

= Does the plugin replace existing images? =

Yes, but only if the optimized version is smaller. The plugin should NEVER create a larger image.

= Can I lower the compression setting for JPGs to save more space? =

Our premium compression can determine the ideal quality setting and give you the best results, but you may also adjust the default quality for conversion and resizing. [Read more...](https://docs.ewww.io/article/12-jpq-quality-and-wordpress)

= The bulk optimizer doesn't seem to be working, what can I do? =

See [https://docs.ewww.io/article/39-bulk-optimizer-failure](https://docs.ewww.io/article/39-bulk-optimizer-failure) for full troubleshooting instructions.

= What are the supported operating systems? =

Free mode using local server compression is supported on Windows, Linux, MacOS, and FreeBSD. The Compress API and Easy IO CDN will work on any OS.

= I want to know more about image optimization, and which options I should choose. =

That's not a question, but since I made it up, I'll answer it. See this resource:
[https://ewww.io/2026/01/12/ewww-whose-images-are-those/](https://ewww.io/2026/01/12/ewww-whose-images-are-those/)

== Screenshots ==

1. Plugin settings page.
2. More settings.
3. Additional optimize column added to media listing. You can see your savings, manually optimize individual images, and restore originals (converted only).
4. Bulk optimization page. You can optimize all your images at once and resume a previous bulk optimization.

== Changelog ==

* Feature requests can be viewed and submitted on our [feedback portal](https://feedback.ewww.io/b/features)
* If you would like to help translate this plugin in your language, [join the team](https://translate.wordpress.org/projects/wp-plugins/ewww-image-optimizer/)

= 8.9.2 =
*Release Date - November 10, 2026*

* added: eio_lazy_noscript and eio_webp_noscript filters to modify/suppress noscript fall-back elements
* changed: Add Missing Dimensions no longer fills in height/width if only one dimension is missing
* fixed: Easy IO skips manually generated srcset attributes with relative URLs
* fixed: Easy IO only rewrites first background image in a CSS property when parsing internal style elements
* fixed: optimization results not shown when bulk optimization is in WebP Only mode
* fixed: failure to remove local images after optimization when using S3 Uploads plugin
* fixed: local optimization blocked on WP NET VPS hosting
* security: improved HTML attribute parsing applied to all front-end filters

= 8.9.1 =
*Release Date - October 29, 2026*

* deprecated: support for PHP versions older than 8.2 will be removed in version 9.0.0
* fixed: some images are not auto-optimized if thumbnail dimensions are set to zero
* fixed: WebP thumbnails for images edited within WordPress use incorrect source image
* fixed: Force Re-optimize does not recreate WebP images when using ImageMagick
* security: Lazy Load HTML attribute parsing is now stricter and more secure

= 8.9.0 =
*Release Date - October 13, 2026*

* added: option to disable resizing via maximum dimensions on media uploader and in post editor
* fixed: regression in Easy IO handling of style attributes causes HTML entities to be double-encoded
* fixed: PNG metadata not removed when using local optipng
* fixed: images with fetchpriority="high" do not get skipped by Lazy Load when Picture WebP delivery is enabled
* fixed: duplicate WebP delivery checks run on settings page
* fixed: race condition with some LiteSpeed servers causes incorrect WebP test image to display
* fixed: images too small for thumbnails failed to optimize automatically on upload
* security: yet more hardening against stored XSS attacks, thanks to WPScan for reporting 

= 8.8.0 =
*Release Date - September 24, 2026*

* added: quality setting for Premium compression, Premium Plus removed/migrated to quality 77
* fixed: fatal error when fetching remote images via WP Offload Media due to strict type casting
* fixed: multisite file modification outside upload directory
* security: PHP object injection, reported by Karthik Ramakrishnan
* security: further hardening of stored XSS fix, reported by Charles Vosburgh and Intrudify
* security: prevent reflected XSS

= 8.7.7 =
*Release Date - September 1, 2026*

* fixed: LQIP/DCIP inputs not available immediately after Easy IO activation
* security: ensure all CDN image URLs are properly escaped to prevent XSS

= 8.7.6 =
*Release Date - August 20, 2026*

* added: option to disable client-side media processing in WP 7.1, mostly for animated GIF images and indexed (palette) PNG images
* fixed: compatibility with client-side media processing in WP 7.1
* fixed: Easy IO modifies URLs in REST API endpoints used by media uploader in WP 7.1
* fixed: WebP conversion via Imagick throws fatal error when source file goes missing
* fixed: PNG to JPG conversion via API sometimes results in black background for 8-bit images
* fixed: Auto-scaling sometimes makes images too large (or too small) when CSS width is set to `auto`

= 8.7.5 =
*Release Date - August 5, 2026*

* improved: use WP file access functions wherever possible
* fixed: PHP notices in BuddyPress/BuddyBoss compatibility functions
* removed: PNG to JPG auto-convert for large PNG images

= 8.7.4 =
*Release Date - July 16, 2026*

* security: prevent authenticated XSS

= 8.7.3 =
*Release Date - July 9, 2026*

* added: ewww_image_optimizer_cloud_based_media filter for cloud-based storage plugins to integrate with optimization processes

= 8.7.2 =
*Release Date - June 10, 2026*

* changed: re-test mechanism for background optimization only runs on settings, and improved error reporting for re-testing
* fixed: cross-site image collisions in remote_push/remote_fetch on multisite with S3 Offload plugin, props @earthlingdavey
* fixed: bulk JS enqueued twice

= 8.7.1 =
*Release Date - June 4, 2026*

* fixed: JS/CSS URLs created by WP Rocket are not delivered via Easy IO CDN
* fixed: docs/help links for Image Detective and Max Image Dimensions
* fixed: search during bulk optimization does not pause table updates

= 8.7.0 =
*Release Date - May 21, 2026*

* changed: Linux binaries are now 64-bit for better compatibility with modern servers
* fixed: Image Detective uses incorrect dimensions for auto-sized srcset images
* fixed: size detection for images using native lazy load
* fixed: PHP error adding global Lazy Load exclusion with Image Detective
* updated: jpegtran to version 10
* updated: optipng to version 7.9.1
* updated: gifsicle to version 1.96
* updated: pngquant to version 3.0.4
* updated: cwebp to version 1.6.0

= 8.6.0 =
*Release Date - May 14, 2026*

* added: LCP image detection helper, along with improved UI for Resize Detection which has been renamed to Image Detective
* added: ability to exclude LCP image from Lazy Load
* added: filters for plugins that offload media to cloud storage to integrate with S3 detection for JS/Picture WebP and Lazy Load, props @alessandrocarrera
* changed: Lazy Load and Easy IO scaling thresholds reduced for improved auto-scaling
* fixed: performance regression when Lazy Load checks parent elements for skip-lazy exceptions
* fixed: new uploads checked twice for optimization when Image Regenerate & Select Crop plugin is active
* fixed: incorrect WebP URLs shown in Media Library when naming mode is empty, usually when media is offloaded
* fixed: some front-end options not autoloaded
* fixed: AVIF images rewritten in Force WebP mode

= 8.5.0 =
*Release Date - April 1, 2026*

* changed: foreground/background bulk optimizers merged into common interface on both Settings and Bulk Optimizer pages
* added: option to choose Background or Foreground mode during bulk optimization
* added: Choose whether to include Additional Folders like the theme or other configured folders during bulk optimization
* fixed: some strings in bulk interface not able to be translated properly for RTL locales
* fixed: NextGEN bulk optimizer missing from menu with NextGEN 4.x
* fixed: when media is offloaded, background optimization leaves local copies behind in some rare cases
* fixed: existing images with missing thumbs/sizes do not get properly offloaded by WP Offload Media after bulk optimization
* fixed: list of pending images for bulk optimization sorted incorrectly
* deprecated: direct support for GRAND FlaGallery will be removed soon, use Folders to Optimize setting instead
* deprecated: direct support for NextCellent Gallery will be removed soon, use Folders to Optimize setting instead

= 8.4.1 =
*Release Date - February 19, 2026*

* fixed: PHP warnings with offloaded media in the Media Library
* fixed: WebP naming mode unable to be changed on Cloudflare sites
* fixed: incorrect WebP paths generated for images in root of S3 buckets (S3 Image Optimizer compat)
* fixed: JS/Picture WebP uses incorrect URLs after naming mode is changed and existing .webp files have not been renamed

= 8.4.0 =
*Release Date - February 11, 2026*

* added: ability to choose append or replace for naming of WebP images, props @adamewww
* added: detection for GoDaddy managed WP hosting
* improved: WebP renaming tool for converting from replacement naming to append and vice versa
* fixed: WebP deletion tool does not update database records, props @adamewww
* fixed: Lazy Load setting does not detect presence of Easy IO plugin
* fixed: Easy IO domain not reset after site URL is updated
* fixed: PHP warnings and notices

= 8.3.1 =
*Release Date - December 4, 2025*

* changed: prevent use of deprecated seems_utf8() function on WP 6.9+
* fixed: Lazy Load auto-sizing makes images too small when screen size changes
* fixed: failure to decode CSS background images contained in encoded quotes (&apos;)

= 8.3.0 =
*Release Date - November 19, 2025*

* added: Lazy Load support for background images in external CSS files
* added: View CDN bandwidth usage on settings page
* changed: Lazy Load checks parent element for skip-lazy class
* changed: Lazy Load auto-sizing honors High DPI setting
* changed: Easy IO fills in 450px wide image when responsive (srcset) images have a gap
* changed: Easy IO premium setting moved to zone configuration at https://ewww.io/manage-sites/
* improved: Lazy Load performance when searching for img elements
* improved: Lazy Load placeholder generation is faster and works better with Safari
* fixed: Lazy Load for iframes breaks WP Remote Users Sync plugin
* fixed: PHP warning when attempting conversion of custom thumbnails from certain themes

= 8.2.1 =
*Release Date - August 27, 2025*

* added: filters for cloud storage plugin integration
* fixed: Easy IO misses some preload links
* fixed: PHP error when API quota is exhausted during single image optimization

= 8.2.0 =
*Release Date - July 15, 2025*

* added: JS WebP support for HTML elements/tags added via eio_allowed_background_image_elements filter
* added: Easy IO support for dynamic cropping (crop=1) on WordPress.com sites
* changed: use native ImageMagick methods to detect, and correct, paletted PNG thumbnails
* changed: use authoritative classmap via composer to speed up autoloader, props @nlemoine
* changed: streamlined admin notices
* fixed: indexed PNG thumbnails with 8-bit alpha are distorted by quantization
* fixed: PHP warnings related to HTML parsing
* fixed: missing ImageMagick information on Site Health screen
* fixed: PHP warnings when link URLs contain special regex characters

= Earlier versions =
Please refer to the separate changelog.txt file.

== Credits ==

Written by [Shane Bishop](https://ewww.io) with special thanks to my [Lord and Savior](https://www.iamsecond.com/). Based upon CW Image Optimizer, which was written by [Jacob Allred](http://www.jacoballred.com/) at [Corban Works, LLC](http://www.corbanworks.com/). CW Image Optimizer was based on WP Smush.it. Jpegtran is the work of the Independent JPEG Group. PEL is the work of Martin Geisler, Lars Olesen, and Erik Oskam. Easy IO and HTML parsing classes based upon the Photon module from Jetpack.
