<?php
namespace ShortPixel;
use ShortPixel\ShortPixelLogger\ShortPixelLogger as Log;
use ShortPixel\Helper\UiHelper as UiHelper;

if ( ! defined( 'ABSPATH' ) ) {
 exit; // Exit if accessed directly.
}

?>
<hr class='wp-header-end'>

<div class="wrap is-shortpixel-settings-page <?php echo esc_attr($this->view_mode); ?> ">

<header>
  <h1>
      <?php echo UIHelper::getIcon('res/images/illustration/logo_settings.svg'); ?>
  </h1>

  <div class='top-buttons'>
      <a class='header-button' href="https://wordpress.org/support/plugin/shortpixel-image-optimiser/reviews/?filter=5#new-post" target="_blank">
          <i class='shortpixel-icon star'></i><name><?php esc_html_e('Rate Us','shortpixel-image-optimiser'); ?></name>
      </a>

    <?php if ( !$view->key->hide_api_key ) { ?>
      <a class='header-button' href="https://shortpixel.com/<?php
        echo esc_attr(($view->key->apiKey ? "login/". $view->key->apiKey . "/dashboard" : "login"));
        ?>" target="_blank">
          <i class='shortpixel-icon user'></i><name><?php _e('ShortPixel Account','shortpixel-image-optimiser'); ?></name>
      </a>
    <?php } ?>
  </div>
</header>

  <input type='checkbox' name='heavy_features' value='1' <?php echo ($this->disable_heavy_features) ? 'checked' : '' ?> class='shortpixel-hide' />

<article class='shortpixel-settings'>
  <?php if ($this->view->data->redirectedSettings < 3 && $view->key->is_verifiedkey && false === $this->is_network_page)
  {
    $this->loadView('settings/part-quicktour');
  }

  ?>

  <label class='mobile-menu closed'>
    <span class='open'><?php echo UIHelper::getIcon('res/images/icon/accordion.svg'); ?></span>
    <span class='close'><?php echo UIHelper::getIcon('res/images/icon/close.svg'); ?></span>
    <input type='checkbox'></label>
  <menu>
			<ul>
        <?php if (true === $this->is_network_page): ?>
        <li class='network'>
          <?php echo $this->settingLink([
            'part' => 'network',
            'title' => __('Network Control', 'shortpixel-image-optimiser'),
            'icon' => 'shortpixel-icon dashboard',
          ]); ?>
        </li>
        <?php endif; ?> 
				<li>
          <?php echo $this->settingLink([
              'part' => 'overview',
              'title' =>  __("Overview", "shortpixel-image-optimiser"),
              'icon' => 'shortpixel-icon dashboard',
            ]); ?>
        </li>
				<li>
          <?php echo $this->settingLink([
            'part' => 'optimisation',
            'title' => __("Image Optimization", "shortpixel-image-optimiser"),
            'icon' => 'shortpixel-icon optimization']); ?>
        </li>
        <li class='is-advanced'>
          <?php echo $this->settingLink([
              'part' => 'exclusions',
              'title' => __("Exclusions", "shortpixel-image-optimiser"),
              'icon' => 'shortpixel-icon exclusions']); ?>
        </li>

        <li class='is-advanced'>
          <?php echo $this->settingLink([
            'part' => 'processing',
            'title' => __("Processing", "shortpixel-image-optimiser"),
            'icon' => 'shortpixel-icon processing']); ?>
        </li>
        <li>
					<?php echo $this->settingLink([
            'part' => 'webp',
            'title' => __("WebP/AVIF & CDN", "shortpixel-image-optimiser"),
            'icon' => 'shortpixel-icon webp_avif']); ?>
        </li>
        <li>
            <?php echo $this->settingLink([
                'part' => 'ai', 
                'title' => __('AI Image SEO', 'shortpixel-image-optimiser'), 
                'icon' => 'shortpixel-icon ai'
            ]); ?>
        </li>

				<li class='is-advanced'>
					<?php echo $this->settingLink([
            'part' => 'integrations',
            'title' => __("Integrations", "shortpixel-image-optimiser"),
            'icon' => 'shortpixel-icon integrations']); ?>
        </li>

				<li class='is-advanced'>
          <?php echo $this->settingLink([
            'part' => 'tools',
            'title' => __("Tools", "shortpixel-image-optimiser"),
            'icon' => 'shortpixel-icon tools']); ?>
        </li>

        <li>
          <?php echo $this->settingLink([
            'part' => 'help',
            'title' => __("Help Center", "shortpixel-image-optimiser"),
            'icon' => 'shortpixel-icon help-circle']); ?>
        </li>

        <?php
          if (Log::debugIsActive())
          { ?>
  			<li>
          <?php echo $this->settingLink([
              'part' => 'debug',
              'title' => __("Debug", "shortpixel-image-optimiser"),
              'icon' => 'shortpixel-icon debug']); ?>
        </li>
        <?php } ?>

			</ul>
			<div class="adv_switcher">
				<?php esc_html_e('Advanced Mode','shortpixel-image-optimiser');?>
                		<label class="adv_switch" id="viewmode-toggles">
                        		<input type="checkbox" <?php echo ('advanced' == $this->view_mode) ? 'checked' : '' ?> >
					<span class="adv_slider"></span>
            		    	</label>
			</div>

<?php if (false === $view->is_ai_unlimited && false === $view->hide_banner): ?>
          <div class='upgrade-banner'>
              <div class="robo-container">
                  <div class="robo-from-banner"> <?php echo UIHelper::getIcon('res/img/robo-slider.png'); ?></div>
                  <div class="banner-title">
                      <span class="banner-pretitle"><?php esc_html_e('Upgrade to', 'shortpixel-image-optimiser'); ?></span>
                      <h2>ShortPixel <span class="banner-highlight"><?php esc_html_e('Unlimited AI', 'shortpixel-image-optimiser'); ?></span></h2>
                  </div>
              </div>
              <div class="banner-audience">
                  <span class="dashicons dashicons-building"></span>
                  <span><?php esc_html_e('Ideal for agencies & multi‑site owners', 'shortpixel-image-optimiser'); ?></span>
              </div>
              <div class="banner-line-container">
                  <span class="shortpixel-icon ok"></span>
                  <p><?php esc_html_e('Unlimited AI alt text', 'shortpixel-image-optimiser'); ?> <span class="banner-new-badge"><?php esc_html_e('NEW', 'shortpixel-image-optimiser'); ?></span></p>
              </div>
              <div class="banner-line-container">
                  <span class="shortpixel-icon ok"></span>
                  <p><?php esc_html_e('Unlimited bg removal', 'shortpixel-image-optimiser'); ?> <span class="banner-new-badge"><?php esc_html_e('NEW', 'shortpixel-image-optimiser'); ?></span></p>
              </div>
              <div class="banner-line-container">
                  <span class="shortpixel-icon ok"></span>
                  <p><?php esc_html_e('Unlimited credits', 'shortpixel-image-optimiser'); ?></p>
              </div>
              <div class="banner-line-container">
                  <span class="shortpixel-icon ok"></span>
                  <p><?php esc_html_e('Unlimited websites', 'shortpixel-image-optimiser'); ?></p>
              </div>
              <div class="banner-line-container">
                  <span class="shortpixel-icon ok"></span>
                  <p><?php esc_html_e('Unlimited WebP/AVIF', 'shortpixel-image-optimiser'); ?></p>
              </div>
              <div class="banner-price">
                  <?php printf(
                      /* translators: %s: monthly price, e.g. $13.33 */
                      esc_html__('From %s /mo', 'shortpixel-image-optimiser'),
                      '<strong>$13.33</strong>'
                  ); ?>
              </div>
              <div class='banner-upgrade-button'>
                  <a href="https://shortpixel.com/pricing?utm_source=plugin&utm_medium=spio&utm_campaign=sidebar_banner_main" target="_blank" class="button button-primary" >
                  <i class="shortpixel-icon cart"></i>
                      <?php _e('Upgrade Now', 'shortpixel-image-optimiser'); ?>
                  </a>

              </div>
          </div>
<?php endif; ?>



		</menu>
		<section class="wrapper">
      <form name='wp_shortpixel_options' action='<?php echo esc_url(add_query_arg('noheader', 'true'), $this->url) ?>'  method='post' id='wp_shortpixel_options'>
        <input type='hidden' name='display_part' value="<?php echo esc_attr($this->display_part) ?>" />
        <input type="hidden" name="form_action" value="<?php echo esc_attr($this->form_action); ?>" />

        <?php wp_nonce_field($this->form_action, 'sp-nonce'); ?>

          <?php if (true === $this->is_network_page)
          {
             $this->loadView('settings/part-network-override'); 
             ?>
             <input type="hidden" name="is_network_admin" value="1" /> 
             <?php 
          }
          ?>

          <?php $this->loadView('settings/part-overview'); ?>
          <?php $this->loadView('settings/part-optimisation'); ?>
          <?php $this->loadView('settings/part-processing'); ?>
          <?php $this->loadView('settings/part-webp'); ?>
          <?php $this->loadView('settings/part-ai'); ?>
          <?php $this->loadView('settings/part-integrations'); ?>
          <?php $this->loadView('settings/part-exclusions'); ?>
          <?php $this->loadView('settings/part-help'); ?>

					<?php $this->loadView('settings/part-nokey'); ?>
      </form>
          <?php $this->loadView('settings/part-tools'); ?>
          <?php
            if (Log::debugIsActive())
            {
              $this->loadView('settings/part-debug');
            }
            ?>
		</section>
</article>


    <section class='ajax-save-done'>
        <div class="icon-container">
            <span class="shortpixel-icon ok" aria-hidden="true"></span>
        </div>
        <div class="text-container">
            <h2><?php _e('Settings successfully saved! ', 'shortpixel-image-optimiser'); ?></h2>
            <h3 class='after-save-notices'><span class='notice_count'>X</span> <?php _e('new notices', 'shortpixel-image-optimiser'); ?></h3>
        </div>
    </section>

<?php $this->loadView('settings/part-wso'); ?>
<?php $this->loadView('snippets/part-inline-modal'); ?>
