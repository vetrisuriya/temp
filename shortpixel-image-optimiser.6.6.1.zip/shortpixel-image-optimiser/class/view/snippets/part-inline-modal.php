<?php
namespace ShortPixel;

if ( ! defined( 'ABSPATH' ) ) {
 exit; // Exit if accessed directly.
}
?>

<div id="spioSettingsModalShade" class="spio-modal-shade" style="display:none;"></div>
			 <div id="spioSettingsModal" class="spio-modal spio-hide" style="min-width:610px">
					 <div class="spio-modal-title">
							 <button type="button" class="spio-close-help-button" onclick="">&times;</button>
					 </div>
           <div class="spio-modal-body" style="height:90%;min-height:400px;padding:0;">

					 </div>
			 </div>

			
